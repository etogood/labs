﻿namespace _3.CalculatorPlus
{
    public class CalculatorHistory
    {
        public string Equasion { get; set; }
    }
}
